fun main(){
    print("Your name? ")
    val name = readLine( )

    print("Your surname? ")
    val surname = readLine()

    println("Your fill name is: $name $surname")

}
